# PSD Mapper v0.1 — Excel prototype

Local prototype for estimating peak skin dose (PSD) and displaying 2D/3D skin-dose maps from the event-level Excel export used in this project.

## Important

This is a **commissioning/research prototype**, not a clinically validated dosimetry system. Validate geometry, Ka,r calibration, table/pad attenuation, backscatter and tissue conversion before clinical use.

## What the importer expects

The app reads the `Sheet1` worksheet and uses these fields from the supplied export:

- `DAP` in Gy·cm²
- `KAP` **in Gy**, provisionally interpreted as event reference air kerma Ka,r
- primary and secondary tube angles
- lateral / height / longitudinal table positions
- source-isocentre and source-detector distances
- collimation width and height
- irradiation event type / protocol

The field size at the reference plane is preferentially reconstructed from `DAP / Ka,r`, with the collimation dimensions used to preserve aspect ratio.

## Install on Windows

1. Install Python 3.11 or newer.
2. Open Command Prompt in this folder.
3. Run:

   `python -m pip install -r requirements.txt`

4. Start with:

   `run_windows.bat`

or:

   `python -m streamlit run app.py`

The browser app runs locally on the computer. The uploaded Excel is processed locally by Streamlit; the app contains no network-upload code.

## Current geometry model

- Supine patient represented by an elliptical cylinder.
- Each event is represented by a rectangular pyramidal X-ray beam.
- Primary/secondary angles rotate the beam in 3D.
- Relative table motions move the beam with respect to the patient.
- Only entrance-surface mesh points are scored.
- Ka,r is corrected by inverse square from the reference point to each skin point.
- Dose is multiplied by user-configurable BSF, air-to-tissue factor, table/pad transmission and Ka,r calibration factor.

## Current limitations

- Anatomical position is relative, not absolute.
- Patient contour is simplified.
- Angle and table-axis conventions still need commissioning against the actual angiography system.
- Fixed BSF/tissue/support corrections are placeholders; clinical version should use beam-quality and field-size dependent factors/tables.
- No uncertainty budget yet.
- No DICOM/RDSR cross-check yet.

## Next validation step

Perform a simple phantom test with one AP field and several known LAO/RAO and CRA/CAU fields, recording the Excel export and measuring field position/dose with film or dosimeters. Use that to lock the axis signs, reference origin and dose correction model.
