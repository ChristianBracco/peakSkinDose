from __future__ import annotations

from dataclasses import dataclass
from typing import Dict, List, Tuple, Optional
import math
import numpy as np
import pandas as pd

REQUIRED_COLUMNS = [
    "DAP",
    "Unità Misura DAP",
    "Angolazione primaria tubo (LL)",
    "Angolazione secondaria tubo (AP)",
    "KAP",
    "Unità Misura KAP",
    "Posizione laterale del tavolo",
    "Altezza del tavolo",
    "Distanza sorgente-isocentro",
    "Posizione longitudinale tavolo",
    "Distanza sorgente-detettore",
    "Altezza Collimazione (mm)",
    "Larghezza Collimazione (mm)",
    "Tipo evento irradiazione",
]


def _num(series: pd.Series) -> pd.Series:
    if pd.api.types.is_numeric_dtype(series):
        return pd.to_numeric(series, errors="coerce")
    return pd.to_numeric(
        series.astype(str).str.strip().replace({"-": np.nan, "": np.nan}).str.replace(",", ".", regex=False),
        errors="coerce",
    )


def load_excel(source) -> Tuple[pd.DataFrame, Dict]:
    """Read the event-level Excel export and normalize key numeric columns."""
    df = pd.read_excel(source, sheet_name="Sheet1")
    missing = [c for c in REQUIRED_COLUMNS if c not in df.columns]
    if missing:
        raise ValueError("Missing required columns: " + ", ".join(missing))

    numeric_cols = [
        "DAP", "Angolazione primaria tubo (LL)", "Angolazione secondaria tubo (AP)", "KAP",
        "Posizione laterale del tavolo", "Altezza del tavolo", "Distanza sorgente-isocentro",
        "Posizione longitudinale tavolo", "Distanza sorgente-detettore",
        "Altezza Collimazione (mm)", "Larghezza Collimazione (mm)",
        "KVP", "mAs", "Numero di pulsazioni"
    ]
    for c in numeric_cols:
        if c in df.columns:
            df[c] = _num(df[c])

    # Rows without an accession number are normally trailing/export artefacts.
    if "Accession number" in df.columns:
        df = df[df["Accession number"].notna()].copy()

    kar_units = set(df["Unità Misura KAP"].dropna().astype(str).str.strip())
    dap_units = set(df["Unità Misura DAP"].dropna().astype(str).str.strip())
    if not kar_units.issubset({"Gy"}):
        raise ValueError(f"Unexpected units in 'KAP' column: {sorted(kar_units)}. Expected Gy (interpreted as Ka,r).")
    if not dap_units.issubset({"Gy*cm2", "Gy·cm2", "Gy cm2", "Gy.cm2"}):
        raise ValueError(f"Unexpected DAP units: {sorted(dap_units)}")

    # In this export, the column labelled KAP has units Gy and behaves as event Ka,r.
    df["Ka_r_Gy"] = df["KAP"]
    df["DAP_Gy_cm2"] = df["DAP"]

    summary = {
        "rows": int(len(df)),
        "sum_kar_gy": float(df["Ka_r_Gy"].fillna(0).sum()),
        "sum_dap_gy_cm2": float(df["DAP_Gy_cm2"].fillna(0).sum()),
        "event_types": df["Tipo evento irradiazione"].fillna("Unknown").astype(str).value_counts().to_dict(),
    }
    return df, summary


def nonzero_median(s: pd.Series, default: float = 0.0) -> float:
    x = _num(s).dropna()
    x = x[x != 0]
    return float(x.median()) if len(x) else float(default)


def field_consistency(df: pd.DataFrame, reference_offset_mm: float = 150.0) -> Dict:
    d = df.copy()
    sod = d["Distanza sorgente-isocentro"]
    sid = d["Distanza sorgente-detettore"]
    kar = d["Ka_r_Gy"]
    dap = d["DAP_Gy_cm2"]
    h = d["Altezza Collimazione (mm)"]
    w = d["Larghezza Collimazione (mm)"]
    mask = (kar > 0) & (dap > 0) & (sod > reference_offset_mm) & (sid > 0) & (h > 0) & (w > 0)
    if not mask.any():
        return {"n": 0, "median_ratio": np.nan, "p05": np.nan, "p95": np.nan}
    observed_area_cm2 = dap[mask] / kar[mask]
    detector_area_cm2 = (h[mask] * w[mask]) / 100.0
    projected_area_cm2 = detector_area_cm2 * ((sod[mask] - reference_offset_mm) / sid[mask]) ** 2
    ratio = observed_area_cm2 / projected_area_cm2
    return {
        "n": int(mask.sum()),
        "median_ratio": float(ratio.median()),
        "p05": float(ratio.quantile(0.05)),
        "p95": float(ratio.quantile(0.95)),
    }


def prepare_events(df: pd.DataFrame, reference_offset_mm: float = 150.0) -> Tuple[List[Dict], Dict]:
    ref_lat = nonzero_median(df["Posizione laterale del tavolo"])
    ref_height = nonzero_median(df["Altezza del tavolo"])
    ref_lon = nonzero_median(df["Posizione longitudinale tavolo"])

    events: List[Dict] = []
    omitted = 0
    for i, row in df.iterrows():
        kar = row.get("Ka_r_Gy")
        dap = row.get("DAP_Gy_cm2")
        alpha = row.get("Angolazione primaria tubo (LL)")
        beta = row.get("Angolazione secondaria tubo (AP)")
        sod = row.get("Distanza sorgente-isocentro")
        sid = row.get("Distanza sorgente-detettore")
        lat = row.get("Posizione laterale del tavolo")
        height = row.get("Altezza del tavolo")
        lon = row.get("Posizione longitudinale tavolo")
        wdet = row.get("Larghezza Collimazione (mm)")
        hdet = row.get("Altezza Collimazione (mm)")

        essentials = [kar, alpha, beta, sod, lat, height, lon]
        if any(pd.isna(v) for v in essentials) or kar <= 0 or sod <= reference_offset_mm:
            omitted += 1
            continue

        dref = float(sod - reference_offset_mm)
        wref = href = None

        # Preferred field reconstruction: DAP / Ka,r gives field area at the reference plane.
        # Detector collimation dimensions supply the aspect ratio.
        if pd.notna(dap) and dap > 0 and pd.notna(wdet) and pd.notna(hdet) and wdet > 0 and hdet > 0:
            area_ref_mm2 = float(dap / kar) * 100.0  # cm2 -> mm2
            aspect = float(wdet / hdet)
            wref = math.sqrt(area_ref_mm2 * aspect)
            href = math.sqrt(area_ref_mm2 / aspect)
        elif pd.notna(sid) and sid > 0 and pd.notna(wdet) and pd.notna(hdet) and wdet > 0 and hdet > 0:
            wref = float(wdet) * dref / float(sid)
            href = float(hdet) * dref / float(sid)

        if not wref or not href:
            omitted += 1
            continue

        events.append({
            "row": int(i) + 2,
            "kar": float(kar),
            "dap": float(dap) if pd.notna(dap) else np.nan,
            "alpha": float(alpha),
            "beta": float(beta),
            "sod": float(sod),
            "dref": dref,
            "lat": float(lat),
            "height": float(height),
            "lon": float(lon),
            "wref": float(wref),
            "href": float(href),
            "type": str(row.get("Tipo evento irradiazione", "")),
            "protocol": str(row.get("Protocollo di acquisizione", "")),
        })

    meta = {
        "ref_lat": ref_lat,
        "ref_height": ref_height,
        "ref_lon": ref_lon,
        "omitted": omitted,
        "used": len(events),
    }
    return events, meta


@dataclass
class Phantom:
    width_mm: float = 360.0
    ap_mm: float = 240.0
    length_mm: float = 800.0
    n_theta: int = 180
    n_z: int = 240


@dataclass
class Corrections:
    bsf: float = 1.35
    tissue_f: float = 1.06
    support_transmission: float = 1.0
    kar_calibration: float = 1.0

    @property
    def product(self) -> float:
        return self.bsf * self.tissue_f * self.support_transmission * self.kar_calibration


@dataclass
class GeometrySettings:
    lateral_sign: float = -1.0
    height_sign: float = -1.0
    longitudinal_sign: float = -1.0
    offset_x_mm: float = 0.0
    offset_y_mm: float = 0.0
    offset_z_mm: float = 0.0


def _beam_axes(alpha_deg: float, beta_deg: float):
    a = math.radians(alpha_deg)
    b = math.radians(beta_deg)
    # At 0/0, source is below the supine patient and beam points posterior -> anterior (+y).
    d = np.array([math.sin(a) * math.cos(b), math.cos(a) * math.cos(b), math.sin(b)], dtype=float)
    d /= np.linalg.norm(d)
    e1 = np.array([math.cos(a), -math.sin(a), 0.0], dtype=float)
    e1 /= np.linalg.norm(e1)
    e2 = np.cross(e1, d)
    e2 /= np.linalg.norm(e2)
    return d, e1, e2


def make_skin_grid(phantom: Phantom):
    theta = np.linspace(-math.pi, math.pi, phantom.n_theta, endpoint=False)
    z = np.linspace(-phantom.length_mm / 2, phantom.length_mm / 2, phantom.n_z)
    TH, Z = np.meshgrid(theta, z, indexing="xy")
    a = phantom.width_mm / 2.0
    b = phantom.ap_mm / 2.0
    X = a * np.cos(TH)
    Y = b * np.sin(TH)
    P = np.stack([X, Y, Z], axis=-1).reshape(-1, 3)

    nx = np.cos(TH) / a
    ny = np.sin(TH) / b
    norm = np.sqrt(nx * nx + ny * ny)
    nx /= norm
    ny /= norm
    N = np.stack([nx, ny, np.zeros_like(nx)], axis=-1).reshape(-1, 3)
    return theta, z, TH, Z, X, Y, P, N


def calculate_map(events: List[Dict], meta: Dict, phantom: Phantom, corr: Corrections, geom: GeometrySettings):
    theta, z, TH, Z, X, Y, P, N = make_skin_grid(phantom)
    dose = np.zeros(P.shape[0], dtype=float)
    event_hits = 0

    for e in events:
        d, e1, e2 = _beam_axes(e["alpha"], e["beta"])
        q = np.array([
            geom.lateral_sign * (e["lat"] - meta["ref_lat"]) + geom.offset_x_mm,
            geom.height_sign * (e["height"] - meta["ref_height"]) + geom.offset_y_mm,
            geom.longitudinal_sign * (e["lon"] - meta["ref_lon"]) + geom.offset_z_mm,
        ], dtype=float)
        source = q - e["sod"] * d
        V = P - source
        t = V @ d
        u = V @ e1
        v = V @ e2
        incidence = (N @ d) < 0.0  # keep entrance surface, reject exit surface
        scale = np.maximum(t, 1e-9) / e["dref"]
        inside = (
            (t > 0) & incidence &
            (np.abs(u) <= 0.5 * e["wref"] * scale) &
            (np.abs(v) <= 0.5 * e["href"] * scale)
        )
        if np.any(inside):
            dose[inside] += e["kar"] * (e["dref"] / t[inside]) ** 2 * corr.product
            event_hits += 1

    dose2d = dose.reshape(phantom.n_z, phantom.n_theta)
    peak_flat = int(np.argmax(dose))
    peak_iz, peak_it = np.unravel_index(peak_flat, dose2d.shape)
    peak = {
        "psd_gy": float(dose2d[peak_iz, peak_it]),
        "theta_deg": float(np.degrees(theta[peak_it])),
        "z_mm": float(z[peak_iz]),
        "x_mm": float(X[peak_iz, peak_it]),
        "y_mm": float(Y[peak_iz, peak_it]),
        "iz": int(peak_iz),
        "it": int(peak_it),
    }
    return {
        "theta": theta, "z": z, "TH": TH, "Z": Z, "X": X, "Y": Y,
        "dose": dose2d, "peak": peak, "event_hits": event_hits,
    }


def event_contributions_at_peak(events: List[Dict], meta: Dict, phantom: Phantom, corr: Corrections,
                                geom: GeometrySettings, peak: Dict) -> pd.DataFrame:
    p = np.array([peak["x_mm"], peak["y_mm"], peak["z_mm"]], dtype=float)
    a = phantom.width_mm / 2.0
    b = phantom.ap_mm / 2.0
    n = np.array([p[0] / (a * a), p[1] / (b * b), 0.0], dtype=float)
    n /= np.linalg.norm(n)
    out = []

    for e in events:
        d, e1, e2 = _beam_axes(e["alpha"], e["beta"])
        q = np.array([
            geom.lateral_sign * (e["lat"] - meta["ref_lat"]) + geom.offset_x_mm,
            geom.height_sign * (e["height"] - meta["ref_height"]) + geom.offset_y_mm,
            geom.longitudinal_sign * (e["lon"] - meta["ref_lon"]) + geom.offset_z_mm,
        ], dtype=float)
        source = q - e["sod"] * d
        V = p - source
        t = float(V @ d)
        if t <= 0 or float(n @ d) >= 0:
            continue
        u = float(V @ e1)
        v = float(V @ e2)
        scale = t / e["dref"]
        if abs(u) <= 0.5 * e["wref"] * scale and abs(v) <= 0.5 * e["href"] * scale:
            dose = e["kar"] * (e["dref"] / t) ** 2 * corr.product
            out.append({
                "Excel row": e["row"], "Dose at peak (Gy)": dose, "Ka,r (Gy)": e["kar"],
                "Primary angle (deg)": e["alpha"], "Secondary angle (deg)": e["beta"],
                "Type": e["type"], "Protocol": e["protocol"],
            })
    return pd.DataFrame(out).sort_values("Dose at peak (Gy)", ascending=False) if out else pd.DataFrame()
