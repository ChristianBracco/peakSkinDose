from __future__ import annotations
import io
import numpy as np
import pandas as pd
import plotly.graph_objects as go
import streamlit as st

from psd_engine import (
    load_excel, field_consistency, prepare_events, Phantom, Corrections,
    GeometrySettings, calculate_map, event_contributions_at_peak,
)

st.set_page_config(page_title="PSD Mapper", layout="wide")
st.title("PSD Mapper — Excel event-dose prototype")
st.caption("Local prototype for commissioning/research. Validate geometry and correction factors before clinical use.")

uploaded = st.file_uploader("Drop the event-level Excel dose report (.xlsx)", type=["xlsx"])
if uploaded is None:
    st.info("Upload an Excel export with the same structure as the supplied dose-detail file.")
    st.stop()

try:
    df, summary = load_excel(uploaded)
except Exception as exc:
    st.error(f"Cannot read this file: {exc}")
    st.stop()

with st.sidebar:
    st.header("Patient phantom")
    width = st.number_input("Lateral width (mm)", 180.0, 700.0, 360.0, 5.0)
    ap = st.number_input("AP thickness (mm)", 120.0, 600.0, 240.0, 5.0)
    length = st.number_input("Mapped longitudinal length (mm)", 300.0, 1800.0, 800.0, 25.0)
    resolution = st.selectbox("Map resolution", ["Fast", "Standard", "High"], index=1)
    res = {"Fast": (120, 160), "Standard": (180, 240), "High": (240, 320)}[resolution]

    st.header("Dose corrections")
    st.caption("Commission these values for each X-ray system before clinical use.")
    bsf = st.number_input("Backscatter factor", 1.00, 1.80, 1.35, 0.01)
    tissue_f = st.number_input("Air-to-tissue factor", 0.80, 1.20, 1.06, 0.01)
    support = st.number_input("Table/pad transmission", 0.50, 1.10, 1.00, 0.01)
    calibration = st.number_input("Ka,r calibration factor", 0.80, 1.20, 1.00, 0.01)
    ref_offset = st.number_input("Reference point offset toward source (mm)", 0.0, 300.0, 150.0, 5.0)

    with st.expander("Geometry conventions"):
        st.caption("Use these only during commissioning if a mapped shift is mirrored/reversed.")
        lat_sign = st.selectbox("Table lateral sign", [-1.0, 1.0], index=0)
        h_sign = st.selectbox("Table height sign", [-1.0, 1.0], index=0)
        lon_sign = st.selectbox("Table longitudinal sign", [-1.0, 1.0], index=0)
        off_x = st.number_input("Patient lateral offset from isocentre (mm)", -300.0, 300.0, 0.0, 5.0)
        off_y = st.number_input("Patient AP offset from isocentre (mm)", -300.0, 300.0, 0.0, 5.0)
        off_z = st.number_input("Patient longitudinal offset (mm)", -1000.0, 1000.0, 0.0, 10.0)

try:
    events, meta = prepare_events(df, reference_offset_mm=ref_offset)
except Exception as exc:
    st.error(f"Event preparation failed: {exc}")
    st.stop()

qc = field_consistency(df, reference_offset_mm=ref_offset)

c1, c2, c3, c4 = st.columns(4)
c1.metric("Dose-report rows", f"{summary['rows']}")
c2.metric("Usable irradiation events", f"{meta['used']}")
c3.metric("Total Ka,r", f"{summary['sum_kar_gy']:.3f} Gy")
c4.metric("Total DAP", f"{summary['sum_dap_gy_cm2']:.1f} Gy·cm²")

with st.expander("Input/QC details", expanded=False):
    st.write("Event types", summary["event_types"])
    st.write(
        f"Reference table coordinates (non-zero medians): lateral {meta['ref_lat']:.1f}, "
        f"height {meta['ref_height']:.1f}, longitudinal {meta['ref_lon']:.1f} mm"
    )
    st.write(f"Rows omitted from mapping: {meta['omitted']}")
    if qc["n"]:
        st.write(
            "DAP/Ka,r field-area consistency: observed / geometrically projected collimation area "
            f"median = {qc['median_ratio']:.3f} (5th–95th percentile {qc['p05']:.3f}–{qc['p95']:.3f}, n={qc['n']})."
        )
    st.warning(
        "The Excel column named 'KAP' is interpreted as event Ka,r because its unit is Gy. "
        "This interpretation must be confirmed against the modality/RDSR or a known case during commissioning."
    )

phantom = Phantom(width_mm=width, ap_mm=ap, length_mm=length, n_theta=res[0], n_z=res[1])
corr = Corrections(bsf=bsf, tissue_f=tissue_f, support_transmission=support, kar_calibration=calibration)
geom = GeometrySettings(
    lateral_sign=lat_sign, height_sign=h_sign, longitudinal_sign=lon_sign,
    offset_x_mm=off_x, offset_y_mm=off_y, offset_z_mm=off_z,
)

with st.spinner("Reconstructing beam overlap and accumulating skin dose..."):
    result = calculate_map(events, meta, phantom, corr, geom)
    contrib = event_contributions_at_peak(events, meta, phantom, corr, geom, result["peak"])

peak = result["peak"]
st.subheader("Peak skin dose estimate")
p1, p2, p3, p4 = st.columns(4)
p1.metric("PSD", f"{peak['psd_gy']:.3f} Gy")
p2.metric("Circumferential angle", f"{peak['theta_deg']:.1f}°")
p3.metric("Relative longitudinal position", f"{peak['z_mm']:.0f} mm")
p4.metric("Correction product", f"{corr.product:.3f}")

st.caption(
    "Coordinates are relative to the phantom/reference table position. Absolute anatomical location cannot be inferred reliably from this Excel alone."
)

angle_deg = np.degrees(result["theta"])
heat = go.Figure(go.Heatmap(
    x=angle_deg, y=result["z"], z=result["dose"],
    colorbar=dict(title="Gy"), hovertemplate="Angle %{x:.1f}°<br>z %{y:.0f} mm<br>Dose %{z:.3f} Gy<extra></extra>"
))
heat.add_trace(go.Scatter(
    x=[peak["theta_deg"]], y=[peak["z_mm"]], mode="markers+text",
    marker=dict(size=11, symbol="x"), text=[f"PSD {peak['psd_gy']:.2f} Gy"], textposition="top center",
    name="PSD"
))
heat.update_layout(
    title="Unwrapped skin-dose map",
    xaxis_title="Circumferential angle (deg; -90° ≈ posterior for default convention)",
    yaxis_title="Relative longitudinal position (mm)",
    height=600,
)
st.plotly_chart(heat, use_container_width=True)

with st.expander("3D skin-dose surface", expanded=False):
    surf = go.Figure(go.Surface(
        x=result["X"], y=result["Y"], z=result["Z"], surfacecolor=result["dose"],
        colorbar=dict(title="Gy"), cmin=0, cmax=max(float(result["dose"].max()), 1e-9),
    ))
    surf.add_trace(go.Scatter3d(
        x=[peak["x_mm"]], y=[peak["y_mm"]], z=[peak["z_mm"]],
        mode="markers", marker=dict(size=5), name=f"PSD {peak['psd_gy']:.2f} Gy"
    ))
    surf.update_layout(
        scene=dict(xaxis_title="Lateral mm", yaxis_title="AP mm", zaxis_title="Longitudinal mm", aspectmode="data"),
        height=700, margin=dict(l=0, r=0, t=40, b=0),
    )
    st.plotly_chart(surf, use_container_width=True)

st.subheader("Events contributing to the PSD point")
if contrib.empty:
    st.info("No contributing events were identified at the selected peak grid point.")
else:
    st.dataframe(contrib.head(100), use_container_width=True, hide_index=True)
    csv = contrib.to_csv(index=False).encode("utf-8")
    st.download_button("Download PSD-point event contributions (CSV)", csv, "psd_event_contributions.csv", "text/csv")

st.divider()
st.markdown("**Commissioning items before clinical use**")
st.markdown(
    "1. Confirm the meaning/calibration of the Excel `KAP`-in-Gy field as event Ka,r.  "
    "\n2. Verify primary/secondary angle sign conventions and table-motion axes with known test exposures.  "
    "\n3. Measure table + mattress transmission versus beam quality/angle.  "
    "\n4. Implement beam-quality/field-size dependent BSF and tissue conversion instead of fixed factors.  "
    "\n5. Validate PSD and map position against film/OSLD/TLD or another commissioned dose-tracking system."
)
